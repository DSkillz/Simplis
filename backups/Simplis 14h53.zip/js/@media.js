var $ElmtDiv = $('section > div:first'),
    $ElmtFirstHr = $('.nav div:first'),
    $ElmtThirdHr = $('.nav div:nth-child(3)');

$(window).setBreakpoints({
    // use only largest available vs use all available
    distinct: true,
    // array of widths in pixels where breakpoints
    // should be triggered
    breakpoints: [
        320,
        768,
        996,
        1593
    ]
});